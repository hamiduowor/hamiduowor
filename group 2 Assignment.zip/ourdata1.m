%Reading table into matlab
T = readtable("Nigerian_Road_Traffic_Crashes_2020_2024.csv",Range="A1:K519",ReadRowNames=true);
%Tables for each year
T2020=T(1:37,:);
T2021=T(38:185,:);
T2022=T(186:333,:);
T2023=T(334:481,:);
T2024=T(482:518,:);
%Convert table to structual arrays
A=table2struct(T2020,"ToScalar",false);
B=table2struct(T2021,"ToScalar",false);
C=table2struct(T2022,"ToScalar",false);
D=table2struct(T2023,"ToScalar",false);
E=table2struct(T2024,"ToScalar",false);
%Convert structual arrays to tables
AT=struct2table(A);
BT=struct2table(B);
CT=struct2table(C);
DT=struct2table(D);
ET=struct2table(E);
%Write tables in excel
filename='Mywork.xlsx';
writetable(AT,filename,'Sheet','T2020');
writetable(BT,filename,'Sheet','T2021');
writetable(CT,filename,'Sheet','T2022');
writetable(DT,filename,'Sheet','T2023');
writetable(ET,filename,'Sheet','T2024');
%Data visualization for 2020
state = AT.State;
crashes = AT.Total_Crashes;
invol = AT.Total_Vehicles_Involved
injured=AT.Num_Injured
killed=AT.Num_Killed
bar(crashes);
ylabel('Total Crashes');
xticklabels(state);
xlabel('States');
title('Total Crashes in 2020');
grid on
plot(injured);
xticklabels(state);
ylabel('num injured');
xlabel('state');
title('Number of injured in 2020');
pie3(killed);
title('Pie chart showing the number killed in 2020');
scatter(crashes,invol);
xlabel('State');
ylabel('Total vehicle invloved');
title('Total vehicle involved in crashes');
other=AT.Other_Factors;
polarhistogram(other);
title('Other Factors');
pareto(injured);
title('A pareto chart showing the injured in 2020');
%Data visualization for 2021
state2 = BT.State;
crashes2 = BT.Total_Crashes;
invol2 = BT.Total_Vehicles_Involved
injured2=BT.Num_Injured
killed2=BT.Num_Killed
barh(crashes2);
ylabel('Total Crashes in 2021');
xticklabels(state2);
xlabel('States in Nigeria');
title('Total Crashes in 2021');
grid on
plot(injured2);
xticklabels(state2);
ylabel('Number of injured');
xlabel('States in Nigeria');
title('Number of injured in 2021');
pie(killed2);
title('Pie chart showing the number killed in 2021');
scatter(crashes2,invol2);
xlabel('Number of crashes');
ylabel('Total vehicle invloved');
title('Total vehicle involved in the crashes');
other2=BT.Other_Factors;
polarhistogram(other2);
title('Other Factors contributing to the Crashes');
pareto(injured2);
title('A pareto chart showing the injured in 2021');
%Data visualization for 2022
state3 = CT.State;
crashes3 = CT.Total_Crashes;
invol3 = CT.Total_Vehicles_Involved
injured3=CT.Num_Injured
killed3=CT.Num_Killed
bar(crashes3,'stacked','yellow','EdgeColor','flat');
ylabel('Total Crashes');
xticklabels(state3);
xlabel('States');
title('Total Crashes in 2022');
plot(injured3,'b*');
xticklabels(state3);
ylabel('num injured');
xlabel('states');
title('Number of injured in 2022');
grid on
pie3(killed3,crashes3);
title('Pie chart showing the number killed in 2022');
scatter(crashes3,invol3,'r*');
xlabel('State');
ylabel('Total vehicles invloved');
title('Total vehicles involved in crashes');
grid on
other3=CT.Other_Factors;
waterfall(injured3,other3);
xticklabels(state3);
xlabel('States in Nigeria');
ylabel('Number of injured');
zlabel('Other Factors');
title('Number of injured against other factors in 2022');
%Data visualization for 2023
state4 = DT.State;
crashes4 = DT.Total_Crashes;
invol4 = DT.Total_Vehicles_Involved
injured4=DT.Num_Injured
killed4=DT.Num_Killed
barh(crashes4);
ylabel('Total Crashes');
xticklabels(state4);
xlabel('States in Nigeria');
title('Total Crashes in 2023');
grid on
plot(killed4,'k-o');
xticklabels(state4);
ylabel('num killed');
xlabel('states in Nigeria');
title('Number of injured in 2023');
grid on
scatter(crashes4,invol4,'k*');
xlabel('Crashes in Nigeria');
ylabel('Total vehicles invloved');
title('Total vehicles involved in crashes');
hold on;
plot(crashes4,invol4,'-b','LineWidth',1.5);
hold off;
other4=DT.Other_Factors;
polarhistogram(other4);
title('Other Factors Contributing to the crashes');
pareto(injured4);
title('A pareto chart showing the injured in 2023');
%Data visualization for 2024
state5 = ET.State;
crashes5 = ET.Total_Crashes;
invol5 = ET.Total_Vehicles_Involved;
injured5=ET.Num_Injured;
killed5=ET.Num_Killed;
other5=ET.Other_Factors;
bar(crashes5,'cyan');
ylabel('Total Crashes');
xticklabels(state5);
xlabel('States');
title('Total Crashes in 2024');
grid on
plot(injured5,'-k');
xticklabels(state5);
ylabel('num injured');
xlabel('states');
title('Number of injured in 2024');
pie3(killed5);
title('Pie chart showing the number killed in 2024');
scatter(invol5,other5,'mx');
xlabel('Vehicles involved');
ylabel('Other factors');
title('Total vehicles involved in crashes');